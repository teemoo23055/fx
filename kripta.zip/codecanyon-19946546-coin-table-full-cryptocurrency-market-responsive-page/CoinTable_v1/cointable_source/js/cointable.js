

(function(angular,fx) {

    var isDefined = angular.isDefined,
        isObject = angular.isObject,
        isNumber = angular.isNumber,
        isUndefined = angular.isUndefined,
        isArray = angular.isArray,
        isFunction = angular.isFunction,
        isString = angular.isString,
        element = angular.element,
        noop = angular.noop,
        fromJson = angular.fromJson,
        copy = angular.copy,
        merge = angular.merge,
        isDate = angular.isDate,
        padNumber = function (num, size) {var s = num+'';while (s.length < size) s = '0' + s;return s;},
        inArray = function(array,obj){return isArray(array) ? array.indexOf(obj) != -1 : false;};


    var module = angular.module('CoinTable', ['CoinTableData'])

        .run(['$rootScope','RATES',
            function ($rootScope,RATES) {
                $rootScope.toggleSidebar = function () {
                    element('#sidebar').sidebar('toggle');
                };

                $rootScope.openDonationModal = function () {
                    element('#donation-modal').modal('show');
                };
                $rootScope.copyBTCAddress = function (id) {
                    var input = document.querySelector('#'+id);
                    input.select();
                    document.execCommand('copy');
                };

                fx.base = 'EUR';
                fx.rates = RATES;
            }
        ])

        .factory('GenericList',['$filter',
            function ($filter) {
                var List = function () {
                    this.list = [];
                    this.groups = {
                        size: 50,
                        begin: 0
                    };
                };

                ['push','indexOf', 'splice', 'some', 'map'].forEach(function (method) {
                    List.prototype[method] = function () {
                        return Array.prototype[method].apply(this.list, arguments);
                    };
                });

                List.prototype.clear = function () {
                    this.list = [];
                    this.groups.begin = 0;
                };

                List.prototype.first = function(){
                    return this.list[0];
                };

                List.prototype.last = function(){
                    return this.list[this.list.length-1];
                };

                List.prototype.length = function(){
                    return this.list.length;
                };

                List.prototype.setList = function(array){
                    if(isArray(array)){
                        this.list = array;
                        return true;
                    }
                    else return false
                };

                List.prototype.get = function (index) {
                    return this.list[index];
                };

                List.prototype.each = function(callback){
                    this.list.forEach(callback);
                };

                List.prototype.setGroupSize = function (size) {
                    if(size != this.groups.size){
                        this.groups.begin = 0;
                        this.groups.size = size;
                    }
                };

                List.prototype.setGroup = function (group) {
                    if(this.isCurrentGroup(group)) return;

                    var groups = this.groups,
                        begin = group*groups.size;

                    this.groups.begin = (begin >= this.length()) ? 0 : begin;
                };

                List.prototype.nextGroup = function(){
                    var next = this.currentGroup() + 1,
                        count = this.countGroups();

                    this.setGroup(next % count);
                };

                List.prototype.previousGroup = function(){
                    var previous = this.currentGroup() - 1,
                        count = this.countGroups();

                    previous >= 0 ? this.setGroup(previous) : this.setGroup(count - 1);
                };

                List.prototype.countGroups = function(){
                    var length = this.length();
                    var groups = this.groups;
                    return length == 0 ? 0 : Math.ceil(length / groups.size);
                };

                List.prototype.arrayGroups = function(){
                    var n_groups = this.countGroups(), array = [];

                    for(var i=0; i<n_groups; i++){
                        array.push(i);
                    }
                    return array;
                };

                List.prototype.currentGroup = function () {
                    return Math.floor(this.groups.begin / this.groups.size);
                };

                List.prototype.isCurrentGroup = function (group) {
                    return this.currentGroup() == group;
                };

                List.prototype.getGroup = function(){
                    var groups = this.groups;

                    return $filter('limitTo')(this.list, groups.size, groups.begin);
                };

                List.prototype.isGroupSize = function (size) {
                    return this.groups.size == size;
                };

                return List;

            }
        ])

        .factory('CoinConverter',['$filter','RATES',
            function ($filter,RATES) {


                var CoinConverter = function () {
                    var currencies = Object.keys(RATES);
                    this.currencies = $filter('orderBy')(currencies);
                };


                CoinConverter.prototype.convert = function (from, to, value, formated, sign_numbers) {
                    value = parseFloat(value);
                    return isNaN(value) ?
                        null :
                        formated ?
                            this.priceFormat(fx(value).from(from).to(to), sign_numbers || 5) :
                            fx(value).from(from).to(to) || null;
                };

                CoinConverter.prototype.priceFormat = function (value, count) {
                    var price = null;
                    value = Number(value);

                    if(!isNaN(value)){

                        var value_abs = Math.abs(value), min_int = Math.pow(10, count-1);

                        if(value_abs == 0){
                            price = (0).toFixed(count-1);
                        }
                        else if(value_abs >= min_int){
                            price = value.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                        }
                        else if(value_abs < 1){
                            var val = value_abs, int_val,  str = '';

                            while (true){
                                val *= 10;
                                int_val = Math.floor(val);

                                if(int_val == 0){
                                    str = str.concat('0');
                                }
                                else if(int_val >= min_int){
                                    break;
                                }
                            }

                            price = '0.'.concat(str, val.toFixed(0));
                        }
                        else{

                            var formatted_val = value.toPrecision(count),
                                parts = formatted_val.split('.');

                            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');

                            price = parts[0].concat('.', parts[1]);
                        }

                    }

                    return price;
                };

                CoinConverter.prototype.setFrom = function (from) {
                    merge(fx.settings, {from: from});
                };

                CoinConverter.prototype.setTo = function (to) {
                    merge(fx.settings, {to: to});
                };

                CoinConverter.prototype.hasCurrency = function (cur) {
                    return this.currencies.indexOf(cur) != -1;
                };

                return CoinConverter;

            }
        ])

        .factory('CoinTable',['GenericList','$filter','CoinConverter','CMC',
            function (GenericList,$filter,CoinConverter,CMC) {
                var columns = [
                    {
                        name: 'name',
                        contentText: 'Name',
                        align: 'left',
                        field: 'name',
                        template: 'labeled_name'
                    },
                    {
                        name: 'price',
                        contentText: 'Price',
                        align: 'right',
                        field: 'price_usd',
                        template: 'simple_price'
                    },
                    {
                        name: 'market_cap',
                        contentText: 'Market Cap',
                        align: 'right',
                        field: 'market_cap_usd',
                        template: 'simple_price'
                    },
                    {
                        name: 'available_supply',
                        contentText: 'Available Supply',
                        align: 'right',
                        field: 'available_supply',
                        template: 'available_supply'
                    },
                    {
                        name: 'volume_24h',
                        contentText: 'Volume 24h',
                        align: 'right',
                        field: '24h_volume_usd',
                        template: 'simple_price'
                    },
                    {
                        name: 'change_1h',
                        contentText: '% 1h',
                        align: 'center',
                        field: 'percent_change_1h',
                        template: 'changes'
                    },
                    {
                        name: 'change_24h',
                        contentText: '% 24h',
                        align: 'center',
                        field: 'percent_change_24h',
                        template: 'changes'
                    },
                    {
                        name: 'change_7d',
                        contentText: '% 7d',
                        align: 'center',
                        field: 'percent_change_7d',
                        template: 'changes'
                    }
                ];

                var CoinTable = function (field, group) {
                    GenericList.call(this);

                    this.setList();

                    this.order = {
                        field: field || '',
                        desc: true
                    };

                    this.converter = new CoinConverter();
                    this.market = null;
                    this.ids = null;

                    this.setCurrency('USD');
                    this.setGroupSize(group || 25);
                    this.setTop(100);
                };

                CoinTable.prototype = new GenericList();

                CoinTable.prototype.setCurrency = function (cur) {
                    if(isString(cur) && this.currency != cur && this.converter.hasCurrency(cur)) this.currency = cur;
                };

                CoinTable.prototype.setTop = function (top) {
                    if(top != this.top){
                        this.top = top;
                    }
                };

                CoinTable.prototype.isTop = function (n) {
                    return this.top == n;
                };

                CoinTable.prototype.orderBy = function (field) {
                    if(isString(field)){
                        if(this.isOrderedBy(field)){
                            this.order.desc = !this.order.desc;
                        }
                        else{
                            this.order.field = field;
                            this.order.desc = true;
                        }
                    }
                };

                CoinTable.prototype.isOrderedBy = function (field) {
                    return this.order.field == field;
                };

                CoinTable.prototype.isOrderedDesc = function () {
                    return this.order.desc;
                };

                CoinTable.prototype.currentConversion = function (usd, mrk_symbol) {
                    return this.converter.convert('USD', this.currency, usd, true);
                };

                CoinTable.prototype.showChange = function (change) {
                    change = parseFloat(change);
                    return isNaN(change) ? null : change.toFixed(2);
                };


                CoinTable.prototype.updateResults = function () {

                    var self = this,
                        args = {},
                        source = isArray(self.ids) ?
                            $filter('filter')(CMC, function (market) {
                                return self.ids.indexOf(market.id) != -1;
                            }) :
                            CMC;

                    args[self.order.field] = null;

                    var all = $filter('orderBy')(source, function (market) {
                            return parseInt(market.rank);
                        }),
                        limited = $filter('limitTo')(all, self.top == 'all' ? undefined : self.top),
                        nulls = $filter('filter')(limited, args),
                        rest = $filter('filter')(limited, function (market) {
                            if(market[self.order.field] != null){
                                return true;
                            }
                        }),
                        list = $filter('orderBy')(rest,
                        function (market) {

                            switch(self.order.field){
                                case 'name':
                                case 'symbol':
                                case 'id':
                                    return market[self.order.field];
                                default:
                                    var num = parseFloat(market[self.order.field]);
                                    return isNaN(num) ? 0 : num;
                            }
                        },
                        self.order.desc);

                    if(self.order.desc){
                        list = list.concat(nulls);
                    }
                    else {
                        list = nulls.concat(list);
                    }

                    self.setList(list);
                    self.setGroup(0);
                };

                CoinTable.prototype.setColumns = function (columns_str) {
                    var self = this;

                    if(isString(columns_str) && columns_str.length){
                        columns_str = columns_str.replace(/ /g,'');

                        var cols = columns_str.split(','),
                            checked = [];

                        cols.forEach(function (col) {
                            var found = $filter('filter')(columns, {name: col})[0];

                            if(isObject(found)){
                                checked.push(found);
                            }

                        });

                        self.columns = checked;
                    }
                    else{
                        self.columns = columns;
                    }
                };

                CoinTable.prototype.isColumn = function (column, name) {
                    return isObject(column) && column.name == name;
                };

                CoinTable.prototype.inColumns = function (column, columns) {
                    return isObject(column) && isArray(columns) && (columns.indexOf(column.name) != -1);
                };

                CoinTable.prototype.getMarketById = function (id) {
                    return $filter('filter')(CMC, {id: id})[0];
                };

                CoinTable.prototype.getColumnByName = function (name) {
                    var column = null;

                    this.columns.some(function (col) {
                        if(col.name == name){
                            column = col;
                            return true;
                        }
                    });

                    return column;
                };

                CoinTable.prototype.getAllMarkets = function () {
                    return CMC;
                };

                CoinTable.prototype.setIdsFilter = function (ids) {

                    if(isArray(ids) && ids.length > 0){
                        this.ids = ids;
                    }
                    else this.ids = null;
                };

                CoinTable.prototype.isIdsFiltered = function () {
                    return isArray(this.ids);
                };


                return CoinTable;
            }
        ])

        .directive('coinTable',['$compile','$timeout','THEME',
            function ($compile,$timeout,THEME) {


                var menu = swriter.Segment()
                    .addChild(swriter.Form()
                        .addChild(swriter.Fields()
                            .pushField({class: 'thirteen wide'},
                                swriter.Dropdown(false, {id: 'ct-drop-search'})
                                    .multiple().search().selection()
                                    .pushNativeInput('hidden')
                                    .pushIcon('dropdown')
                                    .defineDefaultText('Search Currencies')
                                    .addDropdownMenu(swriter.Item({'data-value':'{{ market.id }}'},'{{ market.name }}').ngRepeat('market in table.getAllMarkets()'))
                            )
                            .pushField({class: 'three wide'}, swriter.Button(THEME.color).makeLabeledIcon('delete','Clear').fluid().ngClick('clearIds()'))
                        )
                    )
                    .addChild(swriter.Grid({id: 'ct-menu-grid'}).vertically().padded().stackable()
                        .addColumn({class: 'eleven wide'},
                            swriter.Form()
                                .addChild(
                                    swriter.Fields().inline().ngClass('{disabled: table.isIdsFiltered()}')
                                        .defineLabel('Top:')
                                        .addChildren([
                                            swriter.Field(swriter.Checkbox().makeRadio({value: '100', 'ng-model': 'table.top', 'ng-checked': 'true'}).defineLabel('100')),
                                            swriter.Field(swriter.Checkbox().makeRadio({value: '250', 'ng-model': 'table.top'}).defineLabel('250')),
                                            swriter.Field(swriter.Checkbox().makeRadio({value: 'all', 'ng-model': 'table.top'}).defineLabel('All Coins'))
                                        ])
                                )
                                .addChild(
                                    swriter.Fields().inline()
                                        .defineLabel('View:')
                                        .addChildren([
                                            swriter.Field(swriter.Checkbox().makeRadio({value: '25', 'ng-model': 'table.groups.size', 'ng-checked': 'true'}).defineLabel('25')),
                                            swriter.Field(swriter.Checkbox().makeRadio({value: '50', 'ng-model': 'table.groups.size'}).defineLabel('50')),
                                            swriter.Field(swriter.Checkbox().makeRadio({value: '75', 'ng-model': 'table.groups.size'}).defineLabel('75')),
                                            swriter.Field(swriter.Checkbox().makeRadio({value: '100', 'ng-model': 'table.groups.size'}).defineLabel('100'))
                                        ])
                                )
                                .addChild(
                                    swriter.Fields().inline().defineLabel('Show In: ')
                                        .pushField(
                                            swriter.Dropdown(false, {id: 'ct-drop-currency'})
                                                .search().selection()
                                                .pushNativeInput('hidden')
                                                .pushIcon('dropdown')
                                                .defineDefaultText('USD')
                                                .addDropdownMenu(swriter.Item({'data-value':'{{ cur }}'},'{{ cur }}').ngRepeat('cur in table.converter.currencies'))
                                        )
                                )
                                .addChild(
                                    swriter.Fields().inline().defineLabel('Order: ').ngIf('isSmallScreen()')
                                        .pushField(

                                            swriter.Dropdown(true)
                                                .ngModel('table.order.field')
                                                .ngOptions('column.field as column.contentText for column in table.columns')
                                        )
                                        .pushField(
                                            swriter.Button(THEME.color).makeIcon('{{ table.order.desc ? \'arrow down\' : \'arrow up\' }}')
                                                .ngClick('table.order.desc = !table.order.desc')
                                        )
                                )
                        )
                        .addColumn({class: 'ct-arrows bottom aligned five wide'},
                            swriter.Menu(
                                swriter.Div(false).menu().secondary().right()
                                    .pushItem(swriter.Button(THEME.color).makeIcon('chevron left').ngClick('table.previousGroup()'))
                                    .pushItem('{{table.currentGroup()+1}}/{{table.countGroups()}}')
                                    .pushItem(swriter.Button(THEME.color).makeIcon('chevron right').ngClick('table.nextGroup()'))
                            ).small().secondary()
                        )
                    );


                var large_body = swriter.Table().fluid().unstackable().basic()
                        .pushTableHead(swriter.TableRow(swriter.TableHeader()
                            .ngRepeat('column in table.columns')
                            .addClass('{{ column.align }} aligned')
                            .ngClick('table.orderBy(column.field)')
                            .pushHeader(4, [
                                swriter.NativeSpan()
                                    .ngIf('table.isOrderedBy(column.field)')
                                    .addChildren([
                                        swriter.Icon('caret up').ngIf('!table.isOrderedDesc()'),
                                        swriter.Icon('caret down').ngIf('table.isOrderedDesc()')
                                    ]),
                                '{{ column.contentText }}'
                            ])
                        ))
                        .pushTableBody(swriter.TableRow()
                            .addClass('ct-row')
                            .ngRepeat('market in table.getGroup()')
                            .ngClick('table.openMarketModal(market,$event)')
                            .addChild(swriter.TableCell()
                                .addAttrs({'coin-table-entry':'', template: '{{ column.template }}', fieldname: '{{ column.field }}'})
                                .ngRepeat('column in table.columns')
                            )
                        ).ngShow('!isSmallScreen()');



                var small_body = swriter.Accordion({id: 'ct-small-view'}).fluid().styled()
                    .addChildren([
                        swriter.Div(false, [
                            swriter.NativeDiv().addChildren([
                                swriter.Icon('dropdown'),
                                '{{ market.name }}&nbsp;&nbsp;&nbsp;',
                                swriter.NativeSpan({class: 'ct-price', 'ng-style': 'changeStyle(market.percent_change_1h)'},'{{ table.currentConversion(market.price_usd) || \'?\' }} {{ table.currency }}')
                            ])
                        ]).title()
                            .ngRepeatStart('market in table.getGroup()'),
                        swriter.Div(false).content().ngRepeatEnd()
                            .addChildren([
                                swriter.List()
                                    .pushItem(swriter.Label().fluid().basic()
                                        .addText('Price: ')
                                        .defineDetail('{{ table.currentConversion(market.price_usd) || \'?\' }} {{ table.currency }}')
                                    )
                                    .pushItem(swriter.Label().fluid().basic()
                                        .addText('Volume 24h: ')
                                        .defineDetail('{{ table.currentConversion(market[\'24h_volume_usd\']) || \'?\' }} {{ table.currency }}')
                                    )
                                    .pushItem(swriter.Label().fluid().basic()
                                        .addText('Market Cap: ')
                                        .defineDetail('{{ table.currentConversion(market.market_cap_usd) || \'?\' }} {{ table.currency }}')
                                    )
                                    .pushItem(swriter.Label().fluid().basic()
                                        .addText('Total Supply: ')
                                        .defineDetail('{{ table.currentConversion(market.total_supply) || \'?\' }} {{ table.currency }}')
                                    )
                                    .pushItem(swriter.Label().fluid().basic()
                                        .addText('Available Supply: ')
                                        .defineDetail('{{ table.currentConversion(market.available_supply) || \'?\' }} {{ market.symbol }}')
                                    )
                                    .pushItem(swriter.Label(THEME.changes).fluid()
                                        .addText('Change 1h: ')
                                        .defineDetail('{{ table.showChange(market.percent_change_1h) || \'?\' }} %')
                                        .ngClass('changeClass(market.percent_change_1h)')
                                    )
                                    .pushItem(swriter.Label(THEME.changes).fluid()
                                        .addText('Change 24h: ')
                                        .defineDetail('{{ table.showChange(market.percent_change_24h) || \'?\' }} %')
                                        .ngClass('changeClass(market.percent_change_24h)')
                                    )
                                    .pushItem(swriter.Label(THEME.changes).fluid()
                                        .addText('Change 7d: ')
                                        .defineDetail('{{ table.showChange(market.percent_change_7d) || \'?\' }} %')
                                        .ngClass('changeClass(market.percent_change_7d)')
                                    )
                            ])
                    ]).ngShow('isSmallScreen()');

                var template = menu.getHTML() + large_body.getHTML() + small_body.getHTML();

                return {
                    restrict: 'C',
                    scope: {
                        columns: '=',
                        orderby: '='
                    },
                    controller: ['$scope','CoinTable','$window',
                        function ($scope,CoinTable,$window) {

                            $scope.table = new CoinTable();

                            $scope.clearIds = function () {
                                element('#ct-drop-search').dropdown('restore defaults');
                            };


                            var win = element($window),
                                parent_win = element($window.parent);

                            function resize() {
                                var width = win.width(),
                                    height = win.height();

                                if(width != $scope.win_width) {
                                    $timeout(function () {
                                        $scope.win_width = width;
                                    });
                                }
                            }

                            $scope.win_width = win.width();
                            win.on('resize',resize);

                            $scope.$on('$destroy',function () {
                                win.off('resize', resize);
                            });

                            $scope.isSmallScreen = function () {
                                return $scope.win_width < 800;
                            };


                            $scope.changeIcon = function (change) {
                                if(change > 0) return 'arrow up';
                                else if(change < 0) return 'arrow down';
                                else if(change == 0) return 'circle';
                                else return 'help';
                            };

                            $scope.changeStyle = function (change) {
                                if(change > 0) return {color: '#21BA45'};
                                else if(change < 0) return {color: '#DB2828'};
                                else if(change == 0) return {color: '#2185D0'};
                                else return {color: '#F2711C'};
                            };

                            $scope.changeClass = function (change) {
                                if(change > 0) return 'green';
                                else if(change < 0) return 'red';
                                else if(change == 0) return 'blue';
                                else return 'grey';
                            };

                            function updateWatcher(nv,ov) {
                                if(nv != ov){
                                    $scope.table.updateResults();
                                }
                            }
                            $scope.$watch('table.top',updateWatcher,true);
                            $scope.$watch('table.order.field',updateWatcher,true);
                            $scope.$watch('table.order.desc',updateWatcher,true);
                            $scope.$watch('table.ids',updateWatcher,true);
                        }
                    ],
                    link: function (scope, elem, attrs) {



                        scope.table.setColumns(scope.columns);

                        var col = scope.table.getColumnByName(scope.orderby) || scope.table.columns[0];

                        var order = isObject(col) ? col.field : 'market_cap_usd';

                        scope.table.orderBy(order);

                        scope.table.updateResults();

                        elem.html(template);
                        $compile(elem.contents())(scope);

                        element(function () {
                            element('#ct-drop-currency').dropdown({
                                onChange: function(value){
                                    $timeout(function () {
                                        scope.table.setCurrency(value.toUpperCase());
                                    });
                                }
                            });
                            element('#ct-drop-search').dropdown({
                                onChange: function(value){
                                    $timeout(function () {
                                        var ids = value.toLowerCase().split(',');

                                        ids = ids.indexOf('') != -1 ? [] : ids;
                                        scope.table.setIdsFilter(ids);
                                    });
                                }
                            });
                            element('#ct-small-view').accordion();

                        });

                    }
                }
            }
        ])

        .directive('coinTableEntry',['$compile','THEME',
            function ($compile,THEME) {

                var Cache = function () {
                    this.templates = {
                        changes: {},
                        simple_price: {},
                        labeled_name: {},
                        available_supply: {}
                    }
                };

                Cache.prototype.set = function (name,field,html) {
                    this.templates[name] = html;
                };

                Cache.prototype.exists = function (name,field) {
                    return isString(this.templates[name][field]);
                };

                Cache.prototype.get = function(name,field) {
                    return this.templates[name][field];
                };

                var cache = new Cache();

                var templates = {
                    changes: function (field) {

                        if(!cache.exists('changes', field)){
                            var template = swriter.TableCell(
                                swriter.Label(THEME.changes,[
                                    swriter.Icon('{{ changeIcon(market.'+field+') }}'),
                                    '{{ market.'+field+' != null ? table.showChange(market.'+field+') : \'No Data\' }}'
                                ]).small().fluid().ngClass('changeClass(market.'+field+')')
                            ).getHTML();

                            cache.set('changes', field, template);

                            return template;
                        }
                        return cache('changes', field);
                    },
                    simple_price: function (field) {
                        if(!cache.exists('simple_price', field)){
                            var template = swriter.TableCell([
                                swriter.Label({class: 'number-label'}).small().basic()
                                    .addText('{{ table.currentConversion(market[\''+field+'\']) || \'?\' }}')
                                    .defineDetail('{{ table.currency }}').fluid()
                            ]).right().aligned().getHTML();

                            cache.set('simple_price', field, template);

                            return template;
                        }
                        return cache('simple_price', field);
                    },
                    labeled_name: function (field) {
                        if(!cache.exists('labeled_name', field)){
                            var template = swriter.TableCell(
                                swriter.Label(THEME.color)
                                    .addText('{{ market.name }}')
                                    .defineDetail('{{ market.symbol }}').small().fluid()

                            ).getHTML();

                            cache.set('labeled_name', field, template);

                            return template;
                        }
                        return cache('labeled_name', field);
                    },
                    available_supply: function (field) {
                        if(!cache.exists('labeled_name', field)){
                            var template = swriter.TableCell(
                                swriter.Label({class: 'number-label'})
                                    .addText('{{ table.converter.priceFormat(market.available_supply, 3) }}')
                                    .defineDetail('{{ market.symbol }}').small().fluid().basic()
                            ).right().aligned().getHTML();

                            cache.set('available_supply', field, template);

                            return template;
                        }
                        return cache('available_supply', field);
                    }
                };




                return {
                    restrict: 'A',
                    link: function (scope, elem, attrs) {

                        var template = templates[attrs.template] || noop;
                        var compiled = $compile(element(template(attrs.fieldname) || ''))(scope);

                        elem.replaceWith(compiled);
                    }
                }
            }
        ]);
})(angular,fx);


