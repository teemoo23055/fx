/**
 * @license Semantic Writer v1.0
 * (c) 2016 Run Coders (https://codecanyon.net/user/runcoders/portfolio?ref=RunCoders)
 * License: https://codecanyon.net/licenses/standard
 */



var swriter = (function(undefined){

    'use strict';


    var swriter = {
        _version: '1.0'
    };


    function isDefined(value) {return typeof value !== 'undefined';}
    function isObject(value) {return value !== null && typeof value === 'object';}
    function isNumber(value) {return typeof value === 'number';}
    var isArray = Array.isArray;
    function isUndefined(value) {return typeof value === 'undefined';}
    function isString(value) {return typeof value === 'string';}
    function isBoolean(value) {return typeof value === 'boolean';}
    function isFamily(value, constructor) {return !!value && !!constructor && value instanceof constructor}
    function isFunction(value) {return typeof value === 'function';}
    function isEmptyObject(value) {return isObject(value) && Object.keys(value).length === 0;}
    function isAttrs(value) {return isObject(value) && !isArray(value) && !isFamily(value, BaseElement)}


    var constructors = {};


    /**
     * BaseElement
     * @param tag
     * @param attrs
     * @param closing
     * @param content
     * @constructor
     */


    var BaseElement = function(tag, attrs, closing, content) {

        this.elem_tag = tag;

        this.attrs_list = [];
        this.addAttrs(attrs);

        this.close_tag = isBoolean(closing) ? closing : true;

        this.children_list = [];
        this.text_content = null;
        this.setText(content);
        this.addChildren(content);
        this.addChild(content);

    };
    constructors.BaseElement = BaseElement;

    BaseElement.prototype.setText = function (text) {
        if(isString(text)){
            this.text_content = text;
        }
        return this;
    };

    BaseElement.prototype.addText = function (text, index) {
        return isString(text) ? this.addChild(new BaseElement('_', null, false, text), index) : this;
    };

    BaseElement.prototype.addChild = function (child, index) {
        if(isFamily(child, BaseElement)){
            isNumber(index) ? this.children_list[index] = child  : this.children_list.push(child);
        }
        return this;
    };

    BaseElement.prototype.addChildren = function (children) {
        var self = this;

        if(isArray(children)){
            children.forEach(function (child) {
                self.addChild(child);
                self.addText(child);
            });
        }

        return self;
    };

    BaseElement.prototype.addContent = function (content) {
        this.addText(content);
        this.addChild(content);
        this.addChildren(content);
        return this;
    };

    BaseElement.prototype.getAttributes = function(apostrophe) {
        var self = this,
            hash = {},
            out = '',
            c = apostrophe === true ? '\'': '\"';

        self.attrs_list.forEach(function (layer) {
            Object.keys(layer).forEach(function (key) {
                var args = layer[key];

                isArray(hash[key]) ? hash[key].push(args) : hash[key] = [args];
            });
        });

        Object.keys(hash).forEach(function (key) {
            out += key + '=' + c + hash[key].join(' ') + c +' ';
        });

        return out;
    };

    BaseElement.prototype.getHTML = function (apostrophe) {

        var self = this,
            tag = self.elem_tag,
            closing = self.close_tag,
            code = '';

        if(tag === '_'){
            code = self.text_content || '';
        }
        else{

            code += '<' + tag + ' ' + self.getAttributes(apostrophe) + '>';

            if(isString(self.text_content)){
                code += self.text_content;
            }
            else{
                self.children_list.forEach(function (child) {
                    code += child.getHTML(apostrophe);
                });
            }

            if(closing) code += '</' + tag + '>';
        }

        return code;
    };

    BaseElement.prototype.addAttrs = function (attrs) {
        var self = this;

        if(isArray(attrs)){
            attrs.forEach(function (layer) {
                self.addAttrs(layer);
            });
        }
        else if(isAttrs(attrs)){
            self.attrs_list.push(attrs);
        }

        return self;
    };

    BaseElement.prototype.addClass = function (cls) {
        return this.addAttrs({class: cls});
    };

    BaseElement.prototype.addId = function (id) {
        return this.addAttrs({id: id});
    };

    BaseElement.prototype.addCustomDivCall = function (attrs, content) {
        var self = this;
        var div = new NativeDiv(attrs, content);
        return function () {
            // 0: attrs, 1: content, 2: index
            if(isAttrs(arguments[0])){
                div.addAttrs(arguments[0]);
                div.addContent(arguments[1]);
                return self.addChild(div, arguments[2]);
            }
            // 0: content, 1: index
            div.addContent(arguments[0]);
            return self.addChild(div, arguments[1]);
        }
    };

    BaseElement.prototype.addCustomSpanCall = function (attrs, content) {
        var self = this;
        var span = new NativeSpan(attrs, content);
        return function () {
            // 0: attrs, 1: content, 2: index
            if(isAttrs(arguments[0])){
                span.addAttrs(arguments[0]);
                span.addContent(arguments[1]);
                return self.addChild(span, arguments[2]);
            }
            // 0: content, 1: index
            span.addContent(arguments[0]);
            return self.addChild(span, arguments[1]);
        }
    };

    BaseElement.prototype.addOrCreateCall = function (Element, index) {
        var self = this;
        return function () {
            // 0: [Element]
            if(isFamily(arguments[0], Element)){
                return self.addChild(arguments[0], index);
            }
            // other cases
            var obj = Object.create(Element.prototype);
            Element.apply(obj, arguments);
            return self.addChild(obj, index);
        }
    };

    BaseElement.prototype.addCustomCall = function (tag, attrs, closing, content) {
        var self = this;
        var elem = new BaseElement(tag, attrs, closing, content);
        return function () {
            // 0: attrs, 1: content, 2: index
            if(isAttrs(arguments[0])){
                elem.addAttrs(arguments[0]);
                elem.addContent(arguments[1]);
                return self.addChild(elem, arguments[2]);
            }
            // 0: content, 1: index
            elem.addContent(arguments[0]);
            return self.addChild(elem, arguments[1]);
        };
    };

    BaseElement.prototype.makeLink = function () {
        this.elem_tag = 'a';
        return this;
    };




    var keywords = [
        // A
        'ad', 'active', 'attached', 'animated', 'avatar', 'aligned', 'action', 'author', 'actions',
        'accordion', 'approve',

        // B
        'big', 'breadcrumb', 'bordered', 'basic', 'button', 'buttons', 'blue', 'brown', 'black',
        'bottom', 'below', 'block', 'borderless', 'banner', 'billboard', 'blurring', 'bar', 'bulleted',

        // C
        'corner', 'celled', 'circular', 'content', 'compact', 'clearing', 'centered', 'card', 'cards',
        'comments', 'comment', 'container', 'center', 'completed', 'checkbox', 'column', 'computer',
        'collapsing', 'collapsed', 'checked', 'cookie', 'category', 'cube', 'cancel',

        // D
        'detail', 'divided', 'dividing', 'description', 'disable', 'divider', 'definition', 'down',
        'dropdown', 'default', 'doubling', 'date', 'dimmer', 'dimmed', 'dimmable', 'disabled',


        // E
        'empty', 'error', 'eight', 'eleven', 'equal', 'extra', 'event', 'embed',

        // F
        'floating', 'facebook', 'fade', 'fluid', 'fitted', 'focus', 'floated', 'four', 'five',
        'fourteen', 'fifteen', 'feed', 'form', 'flag', 'field', 'fields', 'fixed', 'fullscreen',
        'flowing',

        // G
        'google', 'green', 'grey', 'grid', 'grouped',

        // H
        'hidden', 'huge', 'horizontal', 'horizontally', 'header', 'half', 'heart',

        // I
        'icon', 'item', 'items', 'inverted', 'instagram', 'image', 'images', 'input', 'instant',
        'inline', 'internally', 'info', 'indicating',

        // J
        'justified',

        // K


        // L
        'labeled', 'link', 'linkedin', 'loading', 'large', 'left', 'label', 'list', 'loader',
        'line', 'leaderboard', 'like',

        // M
        'mini', 'medium', 'massive', 'middle', 'menu', 'message', 'move', 'mobile', 'meta', 'metadata',
        'minimal', 'multiple', 'modal',

        // N
        'negative', 'nine', 'netboard', 'nag',

        // O
        'ordered', 'orange', 'olive', 'one', 'or', 'only',

        // P
        'pointing', 'positive', 'primary', 'purple', 'pink', 'piled', 'padded', 'pagination', 'popup',
        'page', 'panorama', 'progress', 'prompt', 'pusher', 'plus',

        // Q


        // R
        'ribbon', 'relaxed', 'rounded', 'red', 'right', 'rail', 'reveal', 'rotate', 'raised', 'radio',
        'required', 'row', 'reversed', 'rectangle', 'rating', 'results',

        // S
        'selection', 'spaced', 'sub', 'secondary', 'small', 'six', 'seven', 'sixteen', 'segment',
        'segments', 'step', 'steps', 'search', 'stacked', 'stackable', 'section', 'success', 'submit',
        'stretched', 'screen', 'striped', 'single', 'structured', 'selectable', 'sortable', 'square',
        'skyscraper', 'summary', 'statistic', 'statistics', 'styled', 'slider', 'simple', 'scrolling',
        'star', 'shape', 'sides', 'side', 'sidebar', 'sticky',

        // T
        'tag', 'twitter', 'tiny', 'teal', 'top', 'two', 'three', 'ten', 'twelve', 'thirteen', 'table',
        'toggle', 'text', 'transparent', 'tertiary', 'tablet', 'tabular', 'test', 'threaded', 'title',
        'thin', 'tab',

        // U
        'ui', 'up', 'unstackable',

        // V
        'vk', 'violet', 'vertical', 'vertically', 'very', 'value', 'visible',

        // W
        'wide', 'warning', 'width',

        // X


        // Y
        'youtube', 'yellow'

        // Z



    ];

    keywords.forEach(function (cls) {
        BaseElement.prototype[cls] = function () {
            return this.addClass(cls);
        };
    });


    var ng_attrs = [
        {call:'ngApp', name:'ng-app'},
        {call:'ngBind', name:'ng-bind'},
        {call:'ngBindHtml', name:'ng-bind-html'},
        {call:'ngBindTemplate', name:'ng-bind-template'},
        {call:'ngBlur', name:'ng-blur'},
        {call:'ngChange', name:'ng-change'},
        {call:'ngChecked', name:'ng-checked'},
        {call:'ngClass', name:'ng-class'},
        {call:'ngClassEven', name:'ng-class-even'},
        {call:'ngClassOdd', name:'ng-class-odd'},
        {call:'ngClick', name:'ng-click'},
        {call:'ngCloak', name:'ng-cloak'},
        {call:'ngController', name:'ng-controller'},
        {call:'ngCopy', name:'ng-copy'},
        {call:'ngCsp', name:'ng-csp'},
        {call:'ngCut', name:'ng-cut'},
        {call:'ngDblclick', name:'ng-dblclick'},
        {call:'ngDisabled', name:'ng-disable'},
        {call:'ngFocus', name:'ng-focus'},
        {call:'ngForm', name:'ng-form'},
        {call:'ngHide', name:'ng-hide'},
        {call:'ngHref', name:'ng-href'},
        {call:'ngIf', name:'ng-if'},
        {call:'ngInclude', name:'ng-include'},
        {call:'ngInit', name:'ng-init'},
        {call:'ngJq', name:'ng-jq'},
        {call:'ngKeydown', name:'ng-keydown'},
        {call:'ngKeypress', name:'ng-keypress'},
        {call:'ngKeyup', name:'ng-keyup'},
        {call:'ngList', name:'ng-list'},
        {call:'ngMaxlength', name:'ng-malength'},
        {call:'ngMinlength', name:'ng-minlength'},
        {call:'ngModel', name:'ng-model'},
        {call:'ngModelOptions', name:'ng-model-options'},
        {call:'ngMousedown', name:'ng-mousedown'},
        {call:'ngMouseenter', name:'ng-mouseenter'},
        {call:'ngMouseleave', name:'ng-mouseleave'},
        {call:'ngMousemove', name:'ng-mousemove'},
        {call:'ngMouseover', name:'ng-mouseover'},
        {call:'ngMouseup', name:'ng-mouseup'},
        {call:'ngNonBindable', name:'ng-non-bindable'},
        {call:'ngOpen', name:'ng-open'},
        {call:'ngOptions', name:'ng-options'},
        {call:'ngPaste', name:'ng-paste'},
        {call:'ngPattern', name:'ng-pattern'},
        {call:'ngPluralize', name:'ng-pluralize'},
        {call:'ngReadonly', name:'ng-readonly'},
        {call:'ngRepeatStart', name:'ng-repeat-start'},
        {call:'ngRepeatEnd', name:'ng-repeat-end'},
        {call:'ngRepeat', name:'ng-repeat'},
        {call:'ngRequired', name:'ng-required'},
        {call:'ngSelected', name:'ng-selected'},
        {call:'ngShow', name:'ng-show'},
        {call:'ngSrc', name:'ng-src'},
        {call:'ngSrcset', name:'ng-srcset'},
        {call:'ngStyle', name:'ng-style'},
        {call:'ngSubmit', name:'ng-submit'},
        {call:'ngSwitch', name:'ng-switch'},
        {call:'ngSwitchWhen', name:'ng-switch-when'},
        {call:'ngSwitchDefault', name:'ng-switch-default'},
        {call:'ngTransclude', name:'ng-transclude'},
        {call:'ngValue', name:'ng-value'}
    ];

    ng_attrs.forEach(function (attr) {
        BaseElement.prototype[attr.call] = function (val) {
            var args = {};
            args[attr.name] = val || '';

            return this.addAttrs(args);
        };
    });


    /**
     *
     * ELEMENTS
     *
     */

    var Ui = function() {
        isAttrs(arguments[1]) ?
            // 0: tag, 1: attrs, 2: closing, 3: content
            BaseElement.call(this, arguments[0], [{class: 'ui'}, arguments[1]], arguments[2], arguments[3]) :
            // 0: tag, 1: closing, 2: content
            BaseElement.call(this, arguments[0], {class: 'ui'}, arguments[1], arguments[2]);
    };
    constructors.Ui = Ui;

    Ui.prototype = new BaseElement();





    var Div = function() {
        // 0: ui?, 1: attrs, 2: content
        if(isAttrs(arguments[1])){
            var attrs = [arguments[0] === true ? {class: 'ui'} : null, arguments[1]];
            BaseElement.call(this, 'div', attrs, true, arguments[2]);
        }
        // 0: ui?, 2: content
        else{
            BaseElement.call(this, 'div', arguments[0] === true ? {class: 'ui'} : null, true, arguments[1]);
        }
    };
    constructors.Div = Div;

    Div.prototype = new BaseElement();


    /**
     *
     *
     * NATIVE ELEMENTS
     *
     *
     */



    var NativeInput = function () {
        var attrs = {};

        if(isAttrs(arguments[0])){
            if(isString(arguments[1])) attrs.type = arguments[1];
            if(isString(arguments[2])) attrs.name = arguments[2];
            if(isString(arguments[3])) attrs.placeholder = arguments[3];

            BaseElement.call(this, 'input', [attrs, arguments[0]], false)
        }
        else{
            if(isString(arguments[0])) attrs.type = arguments[0];
            if(isString(arguments[1])) attrs.name = arguments[1];
            if(isString(arguments[2])) attrs.placeholder = arguments[2];

            BaseElement.call(this, 'input', attrs, false);
        }

    };
    constructors.NativeInput = NativeInput;

    NativeInput.prototype = new BaseElement();

    NativeInput.prototype.defineName = function (name) {
        return this.addAttrs({name: name});
    };

    NativeInput.prototype.defineType = function (type) {
        return this.addAttrs({type: type});
    };

    NativeInput.prototype.definePlaceHolder = function (placeholder) {
        return this.addAttrs({placeholder: placeholder});
    };






    var NativeParagraph = function() {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'p', arguments[0], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'p', null, true, arguments[0]);
    };
    constructors.NativeParagraph = NativeParagraph;

    NativeParagraph.prototype = new BaseElement();






    var NativeAnchor = function() {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'a', arguments[0], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'a', null, true, arguments[0]);
    };
    constructors.NativeAnchor = NativeAnchor;

    NativeAnchor.prototype = new BaseElement();






    var NativeImage = function() {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'img', arguments[0], false, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'img', null, false, arguments[0]);
    };
    constructors.NativeImage = NativeImage;

    NativeImage.prototype = new BaseElement();






    var NativeDiv = function() {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', arguments[0], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', null, true, arguments[0]);
    };
    constructors.NativeDiv = NativeDiv;

    NativeDiv.prototype = new BaseElement();



    var NativeSpan = function() {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'span', arguments[0], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'span', null, true, arguments[0]);
    };
    constructors.NativeSpan = NativeSpan;

    NativeSpan.prototype = new BaseElement();



    /**
     *
     *
     * SEMANTIC ELEMENTS
     *
     *
     */



    /**
     * Icon
     * @param icon
     * @constructor
     */

    var Icon = function() {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: icon
            BaseElement.call(this, 'i', [{class: arguments[1] + ' icon'}, arguments[0]]) :
            // 0: icon
            BaseElement.call(this, 'i', {class: arguments[0] + ' icon'});
    };
    constructors.Icon = Icon;

    Icon.prototype = new BaseElement();



    /**
     * Flag
     * @param country
     * @constructor
     */

    var Flag = function() {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: flag
            BaseElement.call(this, 'i', [{class: arguments[1] + ' flag'}, arguments[0]]) :
            // 0: flag
            BaseElement.call(this, 'i', {class: arguments[0] + ' flag'});
    };
    constructors.Flag = Flag;

    Flag.prototype = new BaseElement();



    /**
     * Button
     * @param attrs
     * @param children
     * @constructor
     */
    var Button = function() {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'button', [{class: 'ui button'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'button', {class: 'ui button'}, true, arguments[0]);
    };
    constructors.Button = Button;

    Button.prototype = new BaseElement();

    Button.prototype.makeAnimate = function (effect) {
        var self = this;

        effect = isString(effect) ? effect : '';

        self.addAttrs({class: 'animated '+effect, tabindex: '0'});

        self.defineHidden = function () {
            return self.addCustomDivCall({class: 'hidden content'}).apply(self, arguments);
        };

        self.defineVisible = function () {
            return self.addCustomDivCall({class: 'visible content'}).apply(self, arguments);
        };

        return self;
    };

    Button.prototype.makeIcon = function (icon) {
        this.addClass('icon');
        if(isString(icon)) this.addChild(new Icon(icon), 0);
        return this;
    };

    Button.prototype.makeLabeledIcon = function (icon, text, right) {
        this.addClass(right === true ? 'right labeled icon' : 'left labeled icon');

        this.addChild(new Icon(icon), 0);

        this.addText(text, 1);

        return this;
    };




    /**
     * Buttons
     * @param attrs
     * @param children
     * @constructor
     */
    var Buttons = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui buttons'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui buttons'}, true, arguments[0]);
    };
    constructors.Buttons = Buttons;

    Buttons.prototype = new BaseElement();


    Buttons.prototype.makeConditionals = function () {
        var self = this;

        self.defineLeftButton = function () {
            return self.addOrCreateCall(Button, 0).apply(self, arguments);
        };

        self.defineOr = function (text) {

            var attrs = {class: 'or'};

            if(isString(text)){
                attrs['data-text'] = text;
            }

            var or = new NativeDiv(attrs);

            return self.addChild(or, 1);
        };

        self.defineRightButton = function () {
            return self.addOrCreateCall(Button, 2).apply(self, arguments);
        };

        return self;
    };





    var Divider = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui divider'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui divider'}, true, arguments[0]);
    };
    constructors.Divider = Divider;

    Divider.prototype = new BaseElement();





    var Header = function () {
        var level = isNumber(arguments[0]) && arguments[0] < 7 && arguments[0] > 0 ? arguments[0] : 1;

        isAttrs(arguments[1]) ?
            // 0: level, 1: attrs, 2: content
            BaseElement.call(this, 'h' + level, [{class: 'ui header'}, arguments[1]], true, arguments[2]):
            // 0: level, 1: content
            BaseElement.call(this, 'h' + level, {class: 'ui header'}, true, arguments[1]);
    };
    constructors.Header = Header;

    Header.prototype = new BaseElement();




    var Image = function () {

        var attrs = {class: 'ui image'};

        // 0: attrs, 1: src
        if(isAttrs(arguments[0])){
            if(isString(arguments[1]))
                attrs.src = arguments[1];

            BaseElement.call(this, 'img', [attrs, arguments[0]], false);
        }
        // 0: src
        else{
            if(isString(arguments[0]))
                attrs.src = arguments[0];

            BaseElement.call(this, 'img', attrs, false);
        }
    };
    constructors.Image = Image;

    Image.prototype = new BaseElement();

    Image.prototype.defineSrc = function (src) {
        return this.addAttrs({src: src});
    };




    var Images = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui images'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui images'}, true, arguments[0]);
    };
    constructors.Images = Images;

    Images.prototype = new BaseElement();







    var Input = function () {
        this.left_children = [];
        this.right_children = [];
        this.input_obj = new NativeInput('text');

        BaseElement.call(this, 'div', [{class: 'ui input'}, arguments[0]]);
    };
    constructors.Input = Input;

    Input.prototype = new BaseElement();

    Input.prototype.getHTML = function (apostrophe) {
        var self = this,
            tag = self.elem_tag,
            closing = self.close_tag,
            code = '';

        if(tag === '_'){
            code = self.text_content || '';
        }
        else{

            code += '<' + tag + ' ' + self.getAttributes(apostrophe) + '>';

            self.left_children.forEach(function (child) {
                code += child.getHTML(apostrophe);
            });

            code += self.input_obj.getHTML(apostrophe);

            self.right_children.forEach(function (child) {
                code += child.getHTML(apostrophe);
            });

            if(closing) code += '</' + tag + '>';
        }

        return code;
    };

    Input.prototype.defineInputAttrs = function (attrs) {
        this.input_obj.addAttrs(attrs);
        return this;
    };

    Input.prototype.definePlaceHolder = function (placeholder) {
        this.input_obj.definePlaceHolder({placeholder: placeholder});
        return this;
    };

    Input.prototype.defineName = function (name) {
        this.input_obj.defineName({name: name});
        return this;
    };

    Input.prototype.addToLeft = function (content, index) {
        var self = this;

        if(isFamily(content, BaseElement)){
            isNumber(index) ? self.left_children[index] = content  : self.left_children.push(content);
        }
        else if(isString(content)){
            self.addToLeft(new BaseElement('_', null, false, content), index)
        }
        else if(isArray(content)){
            content.forEach(function (child) {
                self.addToLeft(child);
            });
        }

        return self;
    };

    Input.prototype.addToRight = function (content, index) {
        var self = this;

        if(isFamily(content, BaseElement)){
            isNumber(index) ? self.right_children[index] = content  : self.right_children.push(content);
        }
        else if(isString(content)){
            self.addToRight(new BaseElement('_', null, false, content), index)
        }
        else if(isArray(content)){
            content.forEach(function (child) {
                self.addToRight(child);
            });
        }

        return self;
    };

    Input.prototype.makeIcon = function (icon, left) {
        if(left === true){
            this.addClass('left icon');
            this.addToLeft(new Icon(icon));
        }
        else{
            this.addClass('right icon');
            this.addToRight(new Icon(icon));
        }
        return this;
    };

    Input.prototype.makeAction = function (content, left) {
        this.addClass(left === true ? 'left action' : 'right action');

        return left === true ? this.addToLeft(content) : this.addToRight(content);
    };





    var Label = function () {
        isAttrs(arguments[0]) ?
            // 0: tag, 1: attrs, 2: content
            BaseElement.call(this, 'div', [{class: 'ui label'}, arguments[0]], true, arguments[1]) :
            // 0: tag, 1: content
            BaseElement.call(this, 'div', {class: 'ui label'}, true, arguments[0]);
    };
    constructors.Label = Label;
    Label.prototype = new BaseElement();

    Label.prototype.defineDetail = function (content) {
        return this.addCustomDivCall({class: 'detail'}).apply(this, arguments);
    };



    var Labels = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui labels'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui labels'}, true, arguments[0]);

    };
    constructors.Labels = Labels;
    Labels.prototype = new BaseElement();





    var Content = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'content'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'content'}, true, arguments[0]);
    };
    constructors.Content = Content;

    Content.prototype = new BaseElement();

    Content.prototype.defineHeader = function () {
        var tag = arguments[0] === true ? 'a' : 'div';
        var args = Array.prototype.slice.call(arguments);
        args.shift();
        return this.addCustomCall(tag, {class: 'header'}, true).apply(this, args);
    };

    Content.prototype.defineDescription = function () {
        return this.addCustomDivCall({class: 'description'}).apply(this, arguments);
    };

    Content.prototype.defineTitle = function () {
        return this.addCustomDivCall({class: 'title'}).apply(this, arguments);
    };

    Content.prototype.defineCenter = function () {
        return this.addCustomDivCall({class: 'center'}).apply(this, arguments);
    };

    Content.prototype.defineImage = function () {
        return this.addCustomDivCall({class: 'image'}).apply(this, arguments);
    };

    Content.prototype.defineMeta = function () {
        return this.addCustomDivCall({class: 'meta'}).apply(this, arguments);
    };

    Content.prototype.defineMetadata = function () {
        return this.addCustomDivCall({class: 'metadata'}).apply(this, arguments);
    };

    Content.prototype.defineText = function () {
        return this.addCustomDivCall({class: 'text'}).apply(this, arguments);
    };

    Content.prototype.defineAvatar = function () {
        return this.addCustomCall('a', {class: 'avatar'}, true).apply(this, arguments);
    };

    Content.prototype.defineActions = function () {
        return this.addCustomDivCall({class: 'actions'}).apply(this, arguments);
    };

    Content.prototype.defineSummary = function () {
        return this.addCustomDivCall({class: 'summary'}).apply(this, arguments);
    };

    Content.prototype.defineLabel = function () {
        return this.addCustomDivCall({class: 'label'}).apply(this, arguments);
    };





    var Item = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'item'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'item'}, true, arguments[0]);
    };
    constructors.Item = Item;

    Item.prototype = new BaseElement();

    Item.prototype.defineDescription = function () {
        return this.addCustomSpanCall({class: 'description'}).apply(this, arguments);
    };

    Item.prototype.defineText = function () {
        return this.addCustomDivCall({class: 'text'}).apply(this, arguments);
    };

    Item.prototype.defineImage = function () {
        return this.addCustomDivCall({class: 'image'}).apply(this, arguments);
    };




    var List = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui list'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui list'}, true, arguments[0]);
    };
    constructors.List = List;

    List.prototype = new BaseElement();



    var Loader = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui loader'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui loader'}, true, arguments[0]);
    };
    constructors.Loader = Loader;

    Loader.prototype = new BaseElement();

    Loader.prototype.makeText = function (text) {
        this.addClass('text');
        return this.setText(text);
    };






    var Rail = function () {
        isAttrs(arguments[1]) ?
            // 0: attrs, 2: content
            BaseElement.call(this, 'div', [{class: 'ui rail'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui rail'}, true, arguments[0]);
    };
    constructors.Rail = Rail;

    Rail.prototype = new BaseElement();







    var Reveal = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui reveal'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui reveal'}, true, arguments[0]);
    };
    constructors.Reveal = Reveal;

    Reveal.prototype = new BaseElement();

    Reveal.prototype.defineVisible = function (content) {
        return this.addCustomDivCall({class: 'visible content'}).apply(this, arguments);
    };

    Reveal.prototype.defineHidden = function (content) {
        return this.addCustomDivCall({class: 'hidden content'}).apply(this, arguments);
    };





    var Segment = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui segment'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui segment'}, true, arguments[0]);
    };
    constructors.Segment = Segment;

    Segment.prototype = new BaseElement();





    var Segments = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui segments'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui segments'}, true, arguments[0]);
    };
    constructors.Segments = Segments;

    Segments.prototype = new BaseElement();




    var Step = function () {
        var tag = arguments[0] === true ? 'a' : 'div';

        isAttrs(arguments[1]) ?
            // 0: link, 1: attrs, 1: content
            BaseElement.call(this, tag, [{class: 'step'}, arguments[1]], true, arguments[2]) :
            // 0: link, 1: content
            BaseElement.call(this, tag, {class: 'step'}, true, arguments[1]);
    };
    constructors.Step = Step;

    Step.prototype = new BaseElement();





    var Steps = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui steps'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui steps'}, true, arguments[0]);
    };
    constructors.Steps = Steps;

    Steps.prototype = new BaseElement();




    var Breadcrumb = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui breadcrumb'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui breadcrumb'}, true, arguments[0]);
    };
    constructors.Breadcrumb = Breadcrumb;

    Breadcrumb.prototype = new BaseElement();

    Breadcrumb.prototype.addIconDivider = function (icon, index) {
        return this.addChild(new Icon({class: 'divider'}, icon), index);
    };

    Breadcrumb.prototype.addDividerSpan = function () {
        return this.addCustomSpanCall({class: 'divider'}).apply(this, arguments);
    };
    Breadcrumb.prototype.addSection = function (link, active, content, index) {
        var tag = link === true ? 'a' : 'div',
            attrs = {class: 'section'};

        if(active === true) attrs.class += ' active';

        return this.addChild(new BaseElement(tag, attrs, true, content), index);
    };




    var Field = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'field'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'field'}, true, arguments[0]);
    };
    constructors.Field = Field;

    Field.prototype = new BaseElement();

    Field.prototype.defineLabel = function () {
        return this.addCustomCall('label',null,true).apply(this, arguments);
    };

    Field.prototype.addTextarea = function () {
        var attrs;
        // 0: attrs, 1: name, 2: placeholder, 3: rows, 4: index
        if(isAttrs(arguments[0])){
            attrs = arguments[0];

            if(isString(arguments[1])) attrs.name = arguments[1];
            if(isString(arguments[2])) attrs.placeholder = arguments[2];
            if(isString(arguments[3])) attrs.rows = arguments[3];

            return this.addChild(new BaseElement('textarea', attrs), arguments[4]);
        }
        // 0: name, 1: placeholder, 2: rows, 3: index
        attrs = {};
        if(isString(arguments[0])) attrs.name = arguments[0];
        if(isString(arguments[1])) attrs.placeholder = arguments[1];
        if(isString(arguments[2])) attrs.rows = arguments[2];

        return this.addChild(new BaseElement('textarea', attrs), arguments[3]);
    };




    var Fields = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'fields'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'fields'}, true, arguments[0]);
    };
    constructors.Fields = Fields;

    Fields.prototype = new BaseElement();

    Fields.prototype.defineLabel = function () {
        return this.addCustomCall('label', null, true).apply(this, arguments);
    };



    var Form = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'form', [{class: 'ui form'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'form', {class: 'ui form'}, true, arguments[0]);
    };
    constructors.Form = Form;

    Form.prototype = new BaseElement();





    var Accordion = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui accordion'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui accordion'}, true, arguments[0]);
    };
    constructors.Accordion = Accordion;

    Accordion.prototype = new BaseElement();




    var Checkbox = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui checkbox'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui checkbox'}, true, arguments[0]);

        this.input_obj = new NativeInput();
        this.addChild(this.input_obj, 0);

    };
    constructors.Checkbox = Checkbox;

    Checkbox.prototype = new BaseElement();

    Checkbox.prototype.makeStandard = function (attrs) {
        this.input_obj.addAttrs(attrs);
        this.input_obj.defineType('checkbox');
        return this;
    };

    Checkbox.prototype.makeRadio = function (attrs) {
        this.input_obj.addAttrs(attrs);
        this.input_obj.defineType('radio');
        return this.addClass('radio');
    };

    Checkbox.prototype.makeSlider = function (attrs) {
        this.input_obj.addAttrs(attrs);
        this.input_obj.defineType('checkbox');
        return this.addClass('slider');
    };

    Checkbox.prototype.makeToggle = function (attrs) {
        this.input_obj.addAttrs(attrs);
        this.input_obj.defineType('checkbox');
        return this.addClass('toggle');
    };

    Checkbox.prototype.defineLabel = function () {
        // 0: attrs, 1: content
        if(isAttrs(arguments[0])){
            return this.addChild(new BaseElement('label', arguments[0], true, arguments[1]), 1);
        }
        // 0: content
        return this.addChild(new BaseElement('label', null, true, arguments[0]), 1);
    };







    var Dimmer = function () {
        // 0: attrs, 1: content
        if(isAttrs(arguments[0])){
            BaseElement.call(this, 'div', [{class: 'ui dimmer'}, arguments[0]]);
            this.pushContent(arguments[1]);
        }
        // 0: content
        else{
            BaseElement.call(this, 'div', {class: 'ui dimmer'});
            this.pushContent(arguments[0]);
        }

    };
    constructors.Dimmer = Dimmer;

    Dimmer.prototype = new BaseElement();






    var DropdownMenu = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'menu'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'menu'}, true, arguments[0]);

    };
    constructors.DropdownMenu = DropdownMenu;

    DropdownMenu.prototype = new BaseElement();

    DropdownMenu.prototype.defineHeader = function () {
        return this.addCustomDivCall({class: 'header'}).apply(this, arguments);
    };

    DropdownMenu.prototype.addDivider = function () {
        return this.addCustomDivCall({class: 'divider'}).apply(this, arguments);
    };









    var Dropdown = function () {
        var tag = arguments[0] === true ? 'select' : 'div';
        isAttrs(arguments[1]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, tag, [{class: 'ui dropdown'}, arguments[1]], true, arguments[2]) :
            // 0: content
            BaseElement.call(this, tag, {class: 'ui dropdown'}, true, arguments[1]);

    };
    constructors.Dropdown = Dropdown;

    Dropdown.prototype = new BaseElement();

    Dropdown.prototype.makeMultiple = function () {
        return this.elem_tag === 'div' ? this.addClass('multiple') : this.addAttrs({multiple: 'multiple'});
    };

    Dropdown.prototype.defineTextSpan = function () {
        return this.addCustomSpanCall({class: 'text'}).apply(this, arguments);
    };

    Dropdown.prototype.defineDefaultText = function () {
        return this.addCustomDivCall({class: 'default text'}).apply(this, arguments);
    };

    Dropdown.prototype.addOption = function () {
        // 0: attrs, 1: value, 2: content, 3: index
        if(isAttrs(arguments[0])){
            return this.addChild(new BaseElement('option', [{value: arguments[1]}, arguments[0]], true, arguments[2]), arguments[3]);
        }
        // 0: value, 1: content, 2: index
        return this.addChild(new BaseElement('option', {value: arguments[0]}, true, arguments[1]), arguments[2]);
    };

    Dropdown.prototype.addDropdownMenu = function () {
        return this.addOrCreateCall(DropdownMenu).apply(this, arguments);
    };

    Dropdown.prototype.defineHiddenInput = function () {
        // 0: attrs, 1: name
        if(isAttrs(arguments[0])){
            return this.addChild(new NativeInput(arguments[0], 'hidden', arguments[1]));
        }
        // 0: name
        return this.addChild(new NativeInput('hidden', arguments[1]));
    };







    var Embed = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui embed'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui embed'}, true, arguments[0]);
    };
    constructors.Embed = Embed;

    Embed.prototype = new BaseElement();

    Embed.prototype.defineIcon = function (icon) {
        return this.addAttrs({'data-icon': icon});
    };

    Embed.prototype.defineURL = function (url) {
        return this.addAttrs({'data-url': url});
    };

    Embed.prototype.makeYoutube = function (id) {
        return this.addAttrs({'data-source': 'youtube', 'data-id': id});
    };

    Embed.prototype.makeVimeo = function (id) {
        return this.addAttrs({'data-source': 'vimeo', 'data-id': id});
    };

    Embed.prototype.definePlaceHolder = function (url) {
        return this.addAttrs({'data-url': url});
    };






    var Modal = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui modal'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui modal'}, true, arguments[0]);
    };
    constructors.Modal = Modal;

    Modal.prototype = new BaseElement();

    Modal.prototype.defineHeader = function () {
        return this.addCustomDivCall({class: 'header'}).apply(this, arguments);
    };

    Modal.prototype.defineContent = function () {
        return this.addCustomDivCall({class: 'content'}).apply(this, arguments);
    };

    Modal.prototype.defineActions = function () {
        return this.addCustomDivCall({class: 'actions'}).apply(this, arguments);
    };





    var Popup = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui popup'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui popup'}, true, arguments[0]);
    };
    constructors.Popup = Popup;

    Popup.prototype = new BaseElement();

    Popup.prototype.defineHeader = function () {
        return this.addCustomDivCall({class: 'header'}).apply(this, arguments);
    };




    var Progress = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui progress'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui progress'}, true, arguments[0]);
    };
    constructors.Progress = Progress;

    Progress.prototype = new BaseElement();

    Progress.prototype.defineBar = function (progress) {
        var insider = progress === true ? new NativeDiv({class: 'progress'}) : null;
        return this.addCustomDivCall({class: 'bar'}).apply(this, [insider]);
    };

    Progress.prototype.defineLabel = function () {
        return this.addCustomDivCall({class: 'label'}).apply(this, arguments);
    };






    var Rating = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui rating'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui rating'}, true, arguments[0]);
    };
    constructors.Rating = Rating;

    Rating.prototype = new BaseElement();

    Rating.prototype.defineMax = function (max) {
        return this.addAttrs({'data-marating': max});
    };

    Rating.prototype.defineRating = function (rating) {
        return this.addAttrs({'data-rating': rating});
    };







    var Search = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui search'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui search'}, true, arguments[0]);

        this.addChild(new NativeDiv({class: 'results'}), 1);
    };
    constructors.Search = Search;

    Search.prototype = new BaseElement();

    Search.prototype.definePrompt = function () {
        var input = isAttrs(arguments[0]) ?
            // 0: attrs, 1: name, 2: placeholder
            new NativeInput(arguments[0], 'text', arguments[1], arguments[2]) :
            // 0: name, 1: placeholder
            new NativeInput('text', arguments[0], arguments[1]);

        input.addClass('prompt');
        return this.addChild(input, 0);
    };

    Search.prototype.defineIconPrompt = function () {
        var input;
        // 0: div_attrs, 1: input_icon, 2: input_attrs
        if(isAttrs(arguments[0])){
            input = new Input(arguments[0]);
            input.makeIcon(arguments[1]);
            input.defineInputAttrs(arguments[2]);
        }
        // 0: input_icon, 1: input_attrs
        else {
            input = new Input();
            input.makeIcon(arguments[0]);
            input.defineInputAttrs(arguments[1]);
        }

        input.defineInputAttrs({class: 'prompt'});
        return this.addChild(input, 0);
    };








    var Shape = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui shape'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui shape'}, true, arguments[0]);

        this.sides_list = new NativeDiv({class: 'sides'});

        this.addChild(this.sides_list, 0);
    };
    constructors.Shape = Shape;

    Shape.prototype = new BaseElement();

    Shape.prototype.addSide = function () {
        var cls = arguments[0] === true ? 'active side' : 'side';
        var args = Array.prototype.slice.call(arguments);
        args.shift();
        this.sides_list.addCustomDivCall({class: cls}).apply(this.sides_list, args);
        return this;
    };






    var Sidebar = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui sidebar'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui sidebar'}, true, arguments[0]);
    };
    constructors.Sidebar = Sidebar;

    Sidebar.prototype = new BaseElement();





    var Sticky = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui sticky'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui sticky'}, true, arguments[0]);
    };
    constructors.Sticky = Sticky;

    Sticky.prototype = new BaseElement();





    var Grid = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui grid'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui grid'}, true, arguments[0]);
    };
    constructors.Grid = Grid;

    Grid.prototype = new BaseElement();

    Grid.prototype.addRow = function () {
        return this.addCustomDivCall({class: 'row'}).apply(this, arguments);
    };

    Grid.prototype.addColumn = function () {
        return this.addCustomDivCall({class: 'column'}).apply(this, arguments);
    };



    var GridRow = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'row'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'row'}, true, arguments[0]);
    };
    constructors.GridRow = GridRow;

    GridRow.prototype = new BaseElement();

    GridRow.prototype.addColumn = function () {
        return this.addCustomDivCall({class: 'column'}).apply(this, arguments);
    };





    var Menu = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui menu'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui menu'}, true, arguments[0]);
    };
    constructors.Menu = Menu;

    Menu.prototype = new BaseElement();







    var Message = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui message'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui message'}, true, arguments[0]);
    };
    constructors.Message = Message;
    Message.prototype = new BaseElement();




    var TableHead = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'thead', arguments[0], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'thead', null, true, arguments[0]);
    };
    constructors.TableHead = TableHead;
    TableHead.prototype = new BaseElement();



    var TableBody = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'tbody', arguments[0], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'tbody', null, true, arguments[0]);
    };
    constructors.TableBody = TableBody;
    TableBody.prototype = new BaseElement();


    var TableFoot = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'tfoot', arguments[0], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'tfoot', null, true, arguments[0]);
    };
    constructors.TableFoot = TableFoot;
    TableFoot.prototype = new BaseElement();



    var TableRow = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'tr', arguments[0], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'tr', null, true, arguments[0]);
    };
    constructors.TableRow = TableRow;
    TableRow.prototype = new BaseElement();



    var TableHeader = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'th', arguments[0], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'th', null, true, arguments[0]);
    };
    constructors.TableHeader = TableHeader;
    TableHeader.prototype = new BaseElement();


    var TableCell = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'td', arguments[0], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'td', null, true, arguments[0]);
    };
    constructors.TableCell = TableCell;
    TableCell.prototype = new BaseElement();



    var Table = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'table', [{class: 'ui table'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'table', {class: 'ui table'}, true, arguments[0]);
    };
    constructors.Table = Table;

    Table.prototype = new BaseElement();







    var Ad = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui ad'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui ad'}, true, arguments[0]);
    };
    constructors.Ad = Ad;

    Ad.prototype = new BaseElement();







    var Card = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui card'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui card'}, true, arguments[0]);
    };
    constructors.Card = Card;

    Card.prototype = new BaseElement();


    var InsideCard = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'card'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'card'}, true, arguments[0]);
    };
    constructors.InsideCard = InsideCard;

    InsideCard.prototype = new BaseElement();




    var Cards = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui cards'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui cards'}, true, arguments[0]);
    };
    constructors.Cards = Cards;

    Cards.prototype = new BaseElement();






    var Comment = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'comment'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'comment'}, true, arguments[0]);
    };
    constructors.Comment = Comment;

    Comment.prototype = new BaseElement();







    var Comments = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui comments'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui comments'}, true, arguments[0]);
    };
    constructors.Comments = Comments;

    Comments.prototype = new BaseElement();









    var Feed = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui feed'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui feed'}, true, arguments[0]);
    };
    constructors.Feed = Feed;

    Feed.prototype = new BaseElement();







    var FeedEvent = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'event'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'event'}, true, arguments[0]);
    };
    constructors.FeedEvent = FeedEvent;

    FeedEvent.prototype = new BaseElement();






    var Items = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui items'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui items'}, true, arguments[0]);
    };
    constructors.Items = Items;

    Items.prototype = new BaseElement();





    var Statistic = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui statistic'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui statistic'}, true, arguments[0]);
    };
    constructors.Statistic = Statistic;

    Statistic.prototype = new BaseElement();


    var Statistics = function () {
        isAttrs(arguments[0]) ?
            // 0: attrs, 1: content
            BaseElement.call(this, 'div', [{class: 'ui statistics'}, arguments[0]], true, arguments[1]) :
            // 0: content
            BaseElement.call(this, 'div', {class: 'ui statistics'}, true, arguments[0]);
    };
    constructors.Statistics = Statistics;

    Statistics.prototype = new BaseElement();





    Object.keys(constructors).forEach(function (name) {
        var Constructor = constructors[name];

        BaseElement.prototype['push'+name] = function () {
            return this.addOrCreateCall(Constructor).apply(this, arguments);
        };


        swriter[name] = function () {

            var obj = Object.create(Constructor.prototype);
            Constructor.apply(obj, arguments);
            return obj;
        };
    });

    return swriter;

})();