<?php
function randomString($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

ob_start("ob_gzhandler");

define('ROOT_DIRECTORY', dirname(__FILE__).'/');

require_once "custom/config.php";
require_once "includes/socials.php";
require_once "includes/links.php";
require_once "includes/data.php";

$data = getAndUpdateData();


?>
<!DOCTYPE html>
<html lang="en" ng-app="CoinTable">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <link rel="icon" type="image/png" href="images/favicon.png">

    <title><?php echo $config['seo']['title'] ?></title>
    <meta name="description" content="<?php echo $config['seo']['description'] ?>" />
    <meta name="keywords" content="<?php echo $config['seo']['keywords'] ?>" />
    <link rel="canonical" href="<?php echo $config['seo']['url'] ?>" />

    <meta property="og:type" content="website" />
    <meta property="og:url" content="<?php echo $config['seo']['url'] ?>" />
    <meta property="og:title" content="<?php echo $config['seo']['title'] ?>" />
    <meta property="og:description" content="<?php echo $config['seo']['description'] ?>" />
    <meta property="og:site_name" content="<?php echo $config['seo']['name'] ?>" />

    <meta name="twitter:card" content="summary" />
    <meta name="twitter:description" content="<?php echo $config['seo']['description'] ?>" />
    <meta name="twitter:title" content="<?php echo $config['seo']['title'] ?>" />
    <meta name="twitter:url" content="<?php echo $config['seo']['url'] ?>" />

    <script type='application/ld+json'>
    {
        "@context":"http:\/\/schema.org",
        "@type":"WebSite",
        "url":"<?php echo $config['seo']['url'] ?>",
        "name":"<?php echo $config['seo']['name'] ?>"
    }
    </script>


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.10/semantic.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div id="sidebar" class="ui sidebar vertical borderless compact inverted menu">
    <div class="item"></div>
    <?php links_items($config['custom_links']); ?>
    <div class="item"></div>
    <?php social_items($config['social']) ?>

</div>
<div class="pusher">
    <div class="ui large menu">
        <a class="item" ng-click="toggleSidebar()">
            <i class="sidebar icon"></i>
        </a>
    </div>
    <div class="ui stackable grid">
        <div class="centered row">
            <div class="fourteen wide column">
                <h1 class="ui header">
                    <img src="images/logo.png" class="ui image">
                    <?php echo $config['seo']['name']; ?>
                </h1>
                <?php if($config['ads']['top']): ?>
                    <div class="ui centered leaderboard ad">
                        <?php require_once "custom/ads/top.php" ?>
                    </div>
                <?php endif; ?>
                <div id="coin-table" class="coin-table"
                     orderby="'<?php if($config['layout']['orderby']) echo $config['layout']['orderby'] ?>'"
                     columns="'<?php if($config['layout']['columns']) echo $config['layout']['columns'] ?>'"></div>
                <?php if($config['ads']['bottom']): ?>
                    <div class="ui centered leaderboard ad">
                        <?php require_once "custom/ads/bottom.php" ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div id="footer" class="ui black inverted very relaxed segment">
        <div class="ui stackable inverted grid">
            <div class="centered row">
                <div class="four wide column">
                    <h4 class="ui inverted header">Links</h4>
                    <div class="ui inverted link list">
                        <?php links_items($config['custom_links']); ?>
                    </div>
                </div>
                <div class="four wide column">
                    <h4 class="ui inverted header">Follow Us</h4>
                    <div class="ui inverted link list">
                        <?php social_items($config['social']) ?>
                    </div>
                </div>
                <?php if($config['donation']['show']): ?>
                <div class="four wide column">

                    <h4 class="ui inverted header"><?php echo $config['donation']['title']; ?></h4>
                    <p><?php echo $config['donation']['subtitle']; ?></p>
                    <a ng-click="openDonationModal()" class="ui <?php echo $config['layout']['theme']; ?>  labeled icon button">
                        <i class="thumbs up icon"></i>
                        Donate
                    </a>

                </div>
                <?php endif; ?>
            </div>
            <div class="centered row">
                <div class="twelve wide column">
                    <div class="ui inverted section divider"></div>
                </div>
            </div>
            <div class="centered row">
                <div class="center aligned twelve wide column">
                    <img class="ui centered mini image" src="images/logo.png">
                    <div class="ui inverted link list">
                        <div class="item"><?php echo $config['seo']['name']; ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="donation-modal" class="ui modal">
    <div class="header">
        <?php echo $config['donation']['title']; ?>
    </div>
    <div class="content">
        <div class="ui positive message"><?php echo $config['donation']['message']; ?></div>
        <form class="ui form">

            <?php
            foreach ($config['donation']['addresses'] as $name => $address){
                $id = 'addr-'.randomString(20);
                ?>
                <div class="field">
                    <label><?php echo $name ?></label>
                    <div class="ui fluid action input">
                        <input id="<?php echo $id ?>" readonly type="text" value="<?php echo $address ?>">
                        <button class="ui blue right labeled icon button" ng-click="copyBTCAddress('<?php echo $id ?>')">
                            <i class="copy icon"></i>
                            Copy
                        </button>
                    </div>
                </div>
                <?php
            }
            ?>
        </form>
    </div>
    <div class="actions">
        <div class="ui positive right labeled icon button">
            Thank You
            <i class="checkmark icon"></i>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.10/semantic.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/money.js/0.2.0/money.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.6.1/angular.min.js"></script>
<script src="js/semantic-writer.min.js"></script>
<script>
    angular.module('CoinTableData',[])
        .constant('THEME', {
            color: {class: '<?php echo $config['layout']['theme']; ?>'},
            changes: {},
            drop_title: {class: '<?php echo $config['layout']['theme']; ?>'}
        })
        .constant('RATES',<?php echo json_encode($data['rates'])?>)
        .constant('CMC',<?php echo json_encode($data['cmc'])?>);
</script>
<script src="js/cointable.min.js"></script>

<?php require_once "custom/extra_code.php"; ?>
</body>
</html>