<?php

require_once "custom/config.php";

if(isset($_GET['go'])){
    $go = $_GET['go'];
    if(is_string($go)){
        $decoded = base64_decode($go);
        if(isset($config['custom_links'][$decoded])){
            $url = $config['custom_links'][$decoded];
            header("Location: $url");
            die();
        }
    }
}

