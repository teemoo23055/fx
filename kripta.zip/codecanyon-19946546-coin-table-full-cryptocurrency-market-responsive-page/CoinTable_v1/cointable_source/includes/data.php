<?php

function requestGET($url){
    $ch = curl_init();
    $headers = array(
        'Accept: application/json',
        'Content-Type: application/json',
    );
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

function getCoinMarketCap(){
    $cmc_json = requestGET('https://api.coinmarketcap.com/v1/ticker/');
    return is_string($cmc_json) ? json_decode($cmc_json, true) : array();
}

function getRates(){
    $fixer_json = requestGET('https://api.fixer.io/latest');
    if(is_string($fixer_json)){
        $fixer_data = json_decode($fixer_json, true);
        $fixer_data['rates']['EUR'] = 1;
        return $fixer_data['rates'];
    }
    return array();
}


function getDataFile(){
    $json_data = @file_get_contents(ROOT_DIRECTORY.'data.json');
    return json_decode($json_data, true);
}

function saveData($cmc,$rates){

    $data = array(
        'last_update' => time(),
        'cmc' => $cmc,
        'rates' => $rates
    );

    @file_put_contents(ROOT_DIRECTORY.'data.json', json_encode($data));

    return $data;
}

function getAndUpdateData(){
    $time_now = time();
    $data = getDataFile();

    if(is_array($data) && isset($data['last_update']) && $time_now < $data['last_update'] + 600){
        return $data;
    }

    return saveData(getCoinMarketCap(),getRates());
}

