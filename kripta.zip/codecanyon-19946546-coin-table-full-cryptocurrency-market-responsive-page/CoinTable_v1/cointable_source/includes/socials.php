<?php

$socials = array(
    'facebook' => array(
        'icon' => 'facebook',
        'text' => 'Facebook'
    ),
    'twitter' => array(
        'icon' => 'twitter',
        'text' => 'Twitter'
    ),
    'linkedin' => array(
        'icon' => 'linkedin',
        'text' => 'LinkedIn'
    ),
    'google_plus' => array(
        'icon' => 'google plus',
        'text' => 'Google+'
    ),
    'youtube' => array(
        'icon' => 'youtube',
        'text' => 'Youtube'
    ),
    'instagram' => array(
        'icon' => 'instagram',
        'text' => 'Instagram'
    ),
    'pinterest' => array(
        'icon' => 'pinterest',
        'text' => 'Pinterest'
    ),
    'tumblr' => array(
        'icon' => 'tumblr',
        'text' => 'Tumblr'
    ),
    'reddit' => array(
        'icon' => 'reddit',
        'text' => 'Reddit'
    ),
    'github' => array(
        'icon' => 'github',
        'text' => 'GitHub'
    ),
    'stackoverflow' => array(
        'icon' => 'stack overflow',
        'text' => 'Stack Overflow'
    ),
    'codepen' => array(
        'icon' => 'codepen',
        'text' => 'Codepen'
    ),
    'dribble' => array(
        'icon' => 'dribble',
        'text' => 'Dribble'
    ),
    'flickr' => array(
        'icon' => 'flickr',
        'text' => 'Flickr'
    )
);


function social_items($networks){
    global $socials;

    foreach ($networks as $name => $url)
    if(isset($socials[$name]) && is_string($url)){
        $details = $socials[$name];
        ?>
        <a class="item" target="_blank" href="<?php echo $url ?>">
            <i class="<?php echo $details['icon'] ?> icon"></i>
            <?php echo $details['text'] ?>
        </a>
        <?php
    }
}