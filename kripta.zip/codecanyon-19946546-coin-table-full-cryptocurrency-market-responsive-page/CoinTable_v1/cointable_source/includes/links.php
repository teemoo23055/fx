<?php

function links_items($links){

    foreach ($links as $title => $url) {
        $encoded = base64_encode($title);
        ?>
        <a class="item" href="<?php echo "go.php?go=$encoded"; ?>" target="_blank">
            <i class="external icon"></i>
            <?php echo $title; ?>
        </a>
        <?php
    }
}